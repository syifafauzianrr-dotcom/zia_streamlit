def bilangan(angka):
    for i in range(1,angka):
        if i % 2 != 0:
            print(i, end=", ")

bilangan(20)