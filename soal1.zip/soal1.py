def celcius_ke_fahrenheit(c):
    return (9/5) * c + 32

print(celcius_ke_fahrenheit(0))
print(celcius_ke_fahrenheit(100))