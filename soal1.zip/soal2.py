def is_genap(n):
    return n % 2 == 0

print(is_genap(2))